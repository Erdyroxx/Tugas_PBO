
package minuman;


public class minumanKaleng {
    String nama;
    String jenis;
    int isi;
    
    
    public void susuKaleng(){
        this.nama = "BearBland";
    }
}
