
package minuman;


public class Minuman {


    public static void main(String[] args) {
        minumanKaleng  soda = new minumanKaleng();
        soda.nama = "Coca-Cola";
        soda.jenis = "minuman bersoda";
        soda.isi = 900;
        
        minumanKaleng susu = new minumanKaleng();
        susu.nama = "MILO";
        susu.jenis = "minuman susu";
        susu.isi = 980;
        
        minumanKaleng coffe = new minumanKaleng();
        coffe.nama = "Nescafe";
        coffe.jenis = "minuman Kopi";
        coffe.isi = 450;
        
        System.out.println(coffe.nama);
        System.out.println(susu.jenis);
        System.out.println(soda.isi);
        
        System.out.println(soda.isi + susu.isi);
    }
    
}
